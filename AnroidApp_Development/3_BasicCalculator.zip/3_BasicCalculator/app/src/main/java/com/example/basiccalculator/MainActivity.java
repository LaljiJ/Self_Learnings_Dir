package com.example.basiccalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText result_Value1, result_Value2;
    Button result_Division, result_Multiplication, result_Addition, result_Substraction, result_equal;
    TextView result_ResultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            allFindViewIdTake();

            result_equal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String value1,value2;

                    value1 = getValue1Text();
                    value2 = getValue2Text();

                    doOperation(value1,value2);
                }
            });

            return insets;
        });
    }

    public void allFindViewIdTake() {
        result_Value1 = findViewById(R.id.edit_value1);
        result_Value2 = findViewById(R.id.edit_value2);
        result_Division = findViewById(R.id.button_division);
        result_Multiplication = findViewById(R.id.button_multiplication);
        result_Addition = findViewById(R.id.button_addition);
        result_Substraction = findViewById(R.id.button_substraction);
        result_ResultText = findViewById(R.id.textview_result);
        result_equal = findViewById(R.id.button_equal);
    }

    public String getValue1Text(){
        return result_Value1.getText().toString();
    }

    public String getValue2Text(){
        return result_Value2.getText().toString();
    }

    public double doOperation(String num1,String num2)
    {
        int number1 = Integer.parseInt(num1);
        int number2 = Integer.parseInt(num2);

        if (number1 != 0 && number2 != 0)
        {
            int flag = 1;

        }
        else {
            result_ResultText.setText("Please enter proper input");
        }
    return ;
    }

}